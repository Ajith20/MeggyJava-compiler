import meggy.Meggy;

class PA4Example2 {

    public static void main(String[] whatever){
		Meggy.toneStart(Meggy.Tone.C3, 5);
		Meggy.toneStart(Meggy.Tone.F3, 5);
		Meggy.toneStart(Meggy.Tone.E3, 5);
		Meggy.toneStart(Meggy.Tone.G3, 5);
    }
}
