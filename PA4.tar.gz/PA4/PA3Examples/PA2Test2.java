import meggy.Meggy;

 class PA2Test2
{
	public static void main(String[] test)
	{
		Meggy.setPixel((byte)1, (byte)1, Meggy.Color.RED);
	}
}

