import meggy.Meggy;

 class PA2Test1
{
	public static void main(String[] test)
	{

	}
}
