import meggy.Meggy;

class PA4Example4 {

    public static void main(String[] whatever){
		Meggy.toneStart(Meggy.Tone.C3, Meggy.Color.VIOLET);
    }
}
