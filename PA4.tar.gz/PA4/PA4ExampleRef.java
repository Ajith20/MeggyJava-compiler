import meggy.Meggy;

class PA4ExampleRef {

    public static void main(String[] whatever){
	this.mazeRow((byte)0, (byte)7, (byte)7);
    }
    
}