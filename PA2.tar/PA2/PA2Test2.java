import meggy.Meggy;

 class PA2Test2
{
	public static void main(String[] test)
	{

	}
}

