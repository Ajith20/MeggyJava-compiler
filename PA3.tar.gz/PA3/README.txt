Joe Campanelli and Ajith Vemuri
CISC 471/672 Programming Assignment 3
PA3

Notes about make:
We run our code in a Linux environment, so there may need to be changes to the Makefile depending on what testing environment you're using.

Notes about Github commits:
Ajith committed to Github using the username BhargavaRamM one day because his laptop had died.

Our test cases:

PA2Test1.java 
PA2Test2.java 
PA2Test3.java 
PA3Test1.java 
PA3Test2.java 
PA3Test3.java 
PA3CorrectTypes.java 
	-> performs type checking on correct parameters for all PA3 grammar rules
PA3WrongTypes.java 
	-> performs type checking on wrong parameters for all PA3 grammar rules
PA3NoMatchClass.java
	-> demonstrates what happens when the class name doesn't equal the file name