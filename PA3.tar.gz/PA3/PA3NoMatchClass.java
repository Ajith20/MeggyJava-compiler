import meggy.Meggy;

class PA3NoMatch {
	public static void main(String[] string1)
	{
		
		if( ((byte)(byte)(byte)(byte)(byte)(byte)(byte)1 + (byte)2)==3 )
			{
				Meggy.delay((byte)2+(byte)3);
			}
	}
}
