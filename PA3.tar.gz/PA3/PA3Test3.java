import meggy.Meggy;

class PA3Test3
{
	public static void main(String[] string1)
	{
		while(true)
		{
			if(Meggy.checkButton(Meggy.Button.Up))
			{
				Meggy.delay((byte)10 * (byte)20);
			}
			if(false)
			{
			}		
		}
	}
}
